-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 30-01-2013 a las 20:26:11
-- Versión del servidor: 5.0.67
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sys_preg`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alternativa`
--

CREATE TABLE IF NOT EXISTS `alternativa` (
  `cod_alternativa` int(10) unsigned NOT NULL auto_increment,
  `cod_pregunta` int(10) unsigned NOT NULL,
  `valor` varchar(100) collate utf8_spanish_ci NOT NULL,
  `correcta` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`cod_alternativa`),
  KEY `alternativa_FKIndex1` (`cod_pregunta`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=96 ;

--
-- Volcar la base de datos para la tabla `alternativa`
--

INSERT INTO `alternativa` (`cod_alternativa`, `cod_pregunta`, `valor`, `correcta`) VALUES
(1, 8, '5x+6y-7z=10', 0),
(2, 8, '5x+6y-7z=10', 0),
(3, 8, '5x+6y-7z=10', 1),
(4, 8, '5x+6y-7z=10', 0),
(5, 8, 'alternativa ', 0),
(6, 9, '5x+6y-7z=10', 0),
(7, 9, '5x+6y-7z=10', 0),
(8, 9, '5x+6y-7z=10', 1),
(9, 9, '5x+6y-7z=10', 0),
(10, 9, 'alternativa ', 0),
(11, 10, '5x+6y-7z=10', 0),
(12, 10, '5x+6y-7z=10', 0),
(13, 10, '5x+6y-7z=10', 1),
(14, 10, '5x+6y-7z=10', 0),
(15, 10, 'alternativa ', 0),
(16, 11, '5x+6y-7z=10', 0),
(17, 11, '5x+6y-7z=10', 0),
(18, 11, '5x+6y-7z=10', 1),
(19, 11, '5x+6y-7z=10', 0),
(20, 11, 'alternativa ', 0),
(21, 12, '5x+6y-7z=10', 0),
(22, 12, '5x+6y-7z=10', 0),
(23, 12, '5x+6y-7z=10', 1),
(24, 12, '5x+6y-7z=10', 0),
(25, 12, 'alternativa ', 0),
(26, 13, '5x+6y-7z=10', 0),
(27, 13, '5x+6y-7z=10', 0),
(28, 13, '5x+6y-7z=10', 1),
(29, 13, '5x+6y-7z=10', 0),
(30, 13, 'alternativa ', 0),
(31, 14, '5x+6y-7z=10', 0),
(32, 14, '5x+6y-7z=10', 0),
(33, 14, '5x+6y-7z=10', 1),
(34, 14, '5x+6y-7z=10', 0),
(35, 14, 'alternativa ', 0),
(36, 15, '5x+6y-7z=10', 0),
(37, 15, '5x+6y-7z=10', 0),
(38, 15, '5x+6y-7z=10', 1),
(39, 15, '5x+6y-7z=10', 0),
(40, 15, 'alternativa ', 0),
(41, 16, '5x+6y-7z=10', 0),
(42, 16, '5x+6y-7z=10', 0),
(43, 16, '5x+6y-7z=10', 1),
(44, 16, '5x+6y-7z=10', 0),
(45, 16, 'alternativa ', 0),
(46, 17, '5x+6y-7z=10', 0),
(47, 17, '5x+6y-7z=10', 0),
(48, 17, '5x+6y-7z=10', 1),
(49, 17, '5x+6y-7z=10', 0),
(50, 17, 'alternativa ', 0),
(51, 18, '5x+6y-7z=10', 0),
(52, 18, '5x+6y-7z=10', 0),
(53, 18, '5x+6y-7z=10', 1),
(54, 18, '5x+6y-7z=10', 0),
(55, 18, 'alternativa ', 0),
(56, 19, '5x+6y-7z=10', 0),
(57, 19, '5x+6y-7z=10', 0),
(58, 19, '5x+6y-7z=10', 1),
(59, 19, '5x+6y-7z=10', 0),
(60, 19, 'alternativa ', 0),
(61, 1, '5x+6y-7z=10', 0),
(62, 1, '5x+6y-7z=10', 0),
(63, 1, '5x+6y-7z=10', 1),
(64, 1, '5x+6y-7z=10', 0),
(65, 1, '5x+6y-7z=10', 0),
(66, 2, '5x+6y-7z=10', 0),
(67, 2, '5x+6y-7z=10', 0),
(68, 2, '5x+6y-7z=10', 1),
(69, 2, '5x+6y-7z=10', 0),
(70, 2, '5x+6y-7z=10', 0),
(71, 3, '5x+6y-7z=10', 0),
(72, 3, '5x+6y-7z=10', 0),
(73, 3, '5x+6y-7z=10', 1),
(74, 3, '5x+6y-7z=10', 0),
(75, 3, '5x+6y-7z=10', 0),
(76, 4, '5x+6y-7z=10', 0),
(77, 4, '5x+6y-7z=10', 0),
(78, 4, '5x+6y-7z=10', 1),
(79, 4, '5x+6y-7z=10', 0),
(80, 4, '5x+6y-7z=10', 0),
(81, 5, '5x+6y-7z=10', 0),
(82, 5, '5x+6y-7z=10', 0),
(83, 5, '5x+6y-7z=10', 1),
(84, 5, '5x+6y-7z=10', 0),
(85, 5, '5x+6y-7z=10', 0),
(86, 6, '5x+6y-7z=10', 0),
(87, 6, '5x+6y-7z=10', 0),
(88, 6, '5x+6y-7z=10', 1),
(89, 6, '5x+6y-7z=10', 0),
(90, 6, '5x+6y-7z=10', 0),
(91, 7, '5x+6y-7z=10', 0),
(92, 7, '5x+6y-7z=10', 0),
(93, 7, '5x+6y-7z=10', 1),
(94, 7, '5x+6y-7z=10', 0),
(95, 7, '5x+6y-7z=10', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `areas`
--

CREATE TABLE IF NOT EXISTS `areas` (
  `cod_area` int(10) unsigned NOT NULL auto_increment,
  `areas` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_area`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `areas`
--

INSERT INTO `areas` (`cod_area`, `areas`) VALUES
(1, 'Matemáticas'),
(2, 'C.T.A'),
(3, 'Comunicación'),
(4, 'Inglés'),
(5, 'Historia,Geografía y Economía'),
(6, 'Probando edición completada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `capacidad`
--

CREATE TABLE IF NOT EXISTS `capacidad` (
  `cod_capacidad` int(10) unsigned NOT NULL auto_increment,
  `cod_area` int(10) unsigned NOT NULL,
  `capacidad` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_capacidad`),
  KEY `capacidad_FKIndex1` (`cod_area`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `capacidad`
--

INSERT INTO `capacidad` (`cod_capacidad`, `cod_area`, `capacidad`) VALUES
(1, 1, 'Razonamiento y Demostracion'),
(2, 1, 'Comunicacion Matematica'),
(4, 1, 'Actitudes ante el area'),
(5, 2, 'ejemplo joda'),
(6, 2, 'capacidad 2 para cta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE IF NOT EXISTS `curso` (
  `cod_curso` int(10) unsigned NOT NULL auto_increment,
  `cod_area` int(10) unsigned NOT NULL,
  `curso` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_curso`),
  KEY `curso_FKIndex1` (`cod_area`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=12 ;

--
-- Volcar la base de datos para la tabla `curso`
--

INSERT INTO `curso` (`cod_curso`, `cod_area`, `curso`) VALUES
(1, 1, 'Raz. Matem.'),
(2, 1, 'Trigonomet.'),
(3, 1, 'Geometria'),
(4, 1, 'Aritmetica'),
(5, 1, 'Algebra'),
(6, 1, 'Razonamiento Logico'),
(7, 1, 'Matematica'),
(8, 1, 'Estadistica'),
(9, 2, 'Quimica'),
(10, 2, 'Ciencias faperas'),
(11, 2, 'Ciencias forenses');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursogrado`
--

CREATE TABLE IF NOT EXISTS `cursogrado` (
  `cod_grado` int(10) unsigned NOT NULL,
  `cod_curso` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`cod_grado`,`cod_curso`),
  KEY `cursogrado_FKIndex1` (`cod_grado`),
  KEY `cursogrado_FKIndex2` (`cod_curso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `cursogrado`
--

INSERT INTO `cursogrado` (`cod_grado`, `cod_curso`) VALUES
(1, 1),
(1, 4),
(1, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion`
--

CREATE TABLE IF NOT EXISTS `evaluacion` (
  `cod_evaluacion` int(10) unsigned NOT NULL auto_increment,
  `cod_subtema` int(10) unsigned NOT NULL,
  `e_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `fecha_evaluacion` datetime NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `cod_tipoevaluacion` tinyint(10) unsigned NOT NULL,
  `cod_curso` int(10) unsigned NOT NULL,
  `cod_grado` int(10) unsigned NOT NULL,
  `id_tema` int(10) unsigned default NULL,
  `id_subtema` int(10) unsigned default NULL,
  PRIMARY KEY  (`cod_evaluacion`),
  KEY `evaluacion_FKIndex1` (`cod_subtema`),
  KEY `evaluacion_FKIndex2` (`cod_tipoevaluacion`),
  KEY `evaluacion_FKIndex3` (`cod_curso`),
  KEY `evaluacion_FKIndex4` (`cod_grado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `evaluacion`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion_pregunta`
--

CREATE TABLE IF NOT EXISTS `evaluacion_pregunta` (
  `cod_evaluacionpregunta` bigint(20) NOT NULL auto_increment,
  `cod_pregunta` int(10) unsigned NOT NULL,
  `cod_evaluacion` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`cod_evaluacionpregunta`),
  KEY `evaluacion_pregunta_FKIndex1` (`cod_evaluacion`),
  KEY `evaluacion_pregunta_FKIndex2` (`cod_pregunta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `evaluacion_pregunta`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grado`
--

CREATE TABLE IF NOT EXISTS `grado` (
  `cod_grado` int(10) unsigned NOT NULL auto_increment,
  `cod_nivel` int(10) unsigned NOT NULL,
  `grado` varchar(50) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_grado`),
  KEY `grado_FKIndex1` (`cod_nivel`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=12 ;

--
-- Volcar la base de datos para la tabla `grado`
--

INSERT INTO `grado` (`cod_grado`, `cod_nivel`, `grado`) VALUES
(1, 1, 'Primero'),
(2, 1, 'Segundo'),
(3, 1, 'Tercero'),
(4, 1, 'Cuarto'),
(5, 1, 'Quinto'),
(6, 1, 'Sexto'),
(7, 2, 'Primero'),
(8, 2, 'Segundo'),
(9, 2, 'Tercero'),
(10, 2, 'Cuarto'),
(11, 2, 'Quinto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel`
--

CREATE TABLE IF NOT EXISTS `nivel` (
  `cod_nivel` int(10) unsigned NOT NULL auto_increment,
  `nivel` varchar(20) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_nivel`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `nivel`
--

INSERT INTO `nivel` (`cod_nivel`, `nivel`) VALUES
(1, 'Primaria'),
(2, 'Secundaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `niveldificultad`
--

CREATE TABLE IF NOT EXISTS `niveldificultad` (
  `cod_niveldificultad` int(10) unsigned NOT NULL auto_increment,
  `nivel` varchar(20) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_niveldificultad`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `niveldificultad`
--

INSERT INTO `niveldificultad` (`cod_niveldificultad`, `nivel`) VALUES
(1, 'Básico'),
(2, 'Intermedio'),
(3, 'Avanzado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

CREATE TABLE IF NOT EXISTS `pregunta` (
  `cod_pregunta` int(10) unsigned NOT NULL auto_increment,
  `cod_niveldificultad` int(10) unsigned NOT NULL,
  `enunciado` varchar(100) collate utf8_spanish_ci default NULL,
  `cod_curso` int(10) unsigned NOT NULL,
  `cod_grado` int(10) unsigned NOT NULL,
  `id_tema` int(10) unsigned default NULL,
  `id_subtema` int(10) unsigned default NULL,
  `fecha_registro` datetime NOT NULL,
  PRIMARY KEY  (`cod_pregunta`),
  KEY `pregunta_FKIndex1` (`cod_niveldificultad`),
  KEY `pregunta_FKIndex2` (`cod_curso`),
  KEY `pregunta_FKIndex3` (`cod_grado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=20 ;

--
-- Volcar la base de datos para la tabla `pregunta`
--

INSERT INTO `pregunta` (`cod_pregunta`, `cod_niveldificultad`, `enunciado`, `cod_curso`, `cod_grado`, `id_tema`, `id_subtema`, `fecha_registro`) VALUES
(1, 1, 'pregunta de ejemplo', 1, 1, 13, 0, '2013-01-30 15:24:32'),
(2, 1, 'pregunta de ejemplo', 1, 1, 14, 1, '2013-01-30 15:25:54'),
(3, 1, 'Determinar las suma de los n primeros numeros', 1, 1, 14, 1, '2013-01-30 15:27:03'),
(4, 1, 'prueba 1', 1, 1, 14, 1, '2013-01-30 17:47:02'),
(5, 1, 'prueba 2', 1, 1, 14, 1, '2013-01-30 17:47:37'),
(6, 1, 'prueba 3', 1, 1, 14, 1, '2013-01-30 17:49:31'),
(7, 1, 'prueba 4', 1, 1, 14, 1, '2013-01-30 17:50:20'),
(8, 1, 'prueba 5', 1, 1, 14, 1, '2013-01-30 17:51:01'),
(9, 2, 'pregunta de nivel intermedio', 1, 1, 14, 1, '2013-01-30 17:52:22'),
(10, 2, 'pregunta de nivel intermedio 2', 1, 1, 14, 1, '2013-01-30 17:52:58'),
(11, 2, 'pregunta de nivel intermedio 4', 1, 1, 14, 1, '2013-01-30 17:53:02'),
(12, 2, 'pregunta de nivel intermedio 6', 1, 1, 14, 1, '2013-01-30 17:53:05'),
(13, 2, 'pregunta de nivel intermedio 7', 1, 1, 14, 1, '2013-01-30 17:53:10'),
(14, 3, 'pregunta de nivel avanzado 1', 1, 1, 14, 1, '2013-01-30 17:53:44'),
(15, 3, 'pregunta de nivel avanzado 2', 1, 1, 14, 1, '2013-01-30 17:53:45'),
(16, 3, 'pregunta de nivel avanzado 3', 1, 1, 14, 1, '2013-01-30 17:53:45'),
(17, 3, 'pregunta de nivel avanzado 4', 1, 1, 14, 1, '2013-01-30 17:53:46'),
(18, 3, 'pregunta de nivel avanzado 6', 1, 1, 14, 1, '2013-01-30 17:53:47'),
(19, 3, 'pregunta de nivel avanzado 7', 1, 1, 14, 1, '2013-01-30 17:53:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesion`
--

CREATE TABLE IF NOT EXISTS `sesion` (
  `cod_sesion` int(10) unsigned NOT NULL auto_increment,
  `cod_usuario` int(10) unsigned NOT NULL,
  `fecha_login` datetime NOT NULL,
  `ip` varchar(20) collate utf8_spanish_ci NOT NULL,
  `fecha_logout` datetime NOT NULL,
  PRIMARY KEY  (`cod_sesion`),
  KEY `sesion_FKIndex1` (`cod_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `sesion`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subtema`
--

CREATE TABLE IF NOT EXISTS `subtema` (
  `cod_subtema` int(10) unsigned NOT NULL auto_increment,
  `cod_tema` int(10) unsigned NOT NULL,
  `subtema` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_subtema`),
  KEY `subtema_FKIndex1` (`cod_tema`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `subtema`
--

INSERT INTO `subtema` (`cod_subtema`, `cod_tema`, `subtema`) VALUES
(1, 14, 'fapping mental fase 2'),
(3, 14, 'my fcking generation'),
(4, 14, 'trolling maximum');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tema`
--

CREATE TABLE IF NOT EXISTS `tema` (
  `cod_tema` int(10) unsigned NOT NULL auto_increment,
  `cod_curso` int(10) unsigned NOT NULL,
  `cod_grado` int(10) unsigned NOT NULL,
  `tema` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cod_trimestre` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`cod_tema`),
  KEY `tema_FKIndex1` (`cod_curso`),
  KEY `tema_FKIndex2` (`cod_grado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=15 ;

--
-- Volcar la base de datos para la tabla `tema`
--

INSERT INTO `tema` (`cod_tema`, `cod_curso`, `cod_grado`, `tema`, `cod_trimestre`) VALUES
(1, 1, 1, 'desarrollar cubos de rubik', 1),
(4, 1, 1, 'algoritmo de euclides', 1),
(5, 4, 1, 'numeros primos :D', 1),
(6, 4, 1, 'resolucion de problemas unidad 1', 1),
(7, 5, 1, 'Ecuaciones lineales', 1),
(8, 5, 1, 'Fundamentos de algebra', 1),
(9, 5, 1, 'Principios del algebra :D', 1),
(10, 1, 1, 'Razonando y programando', 1),
(11, 5, 1, 'Clases de algebra lineal :D', 1),
(12, 5, 1, 'Ecuaciones diferenciales', 1),
(13, 4, 1, 'conteo de figuras', 1),
(14, 1, 1, 'Fapping mental', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoevaluacion`
--

CREATE TABLE IF NOT EXISTS `tipoevaluacion` (
  `cod_tipoevaluacion` tinyint(10) unsigned NOT NULL auto_increment,
  `tipoevaluacion` varchar(50) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`cod_tipoevaluacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `tipoevaluacion`
--

INSERT INTO `tipoevaluacion` (`cod_tipoevaluacion`, `tipoevaluacion`) VALUES
(1, 'Trabajo para la casa'),
(2, 'Examen Parcial'),
(3, 'Examen Trimestral'),
(4, 'Práctica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trimestre`
--

CREATE TABLE IF NOT EXISTS `trimestre` (
  `cod_trimestre` int(10) unsigned NOT NULL auto_increment,
  `trimestre` char(4) collate utf8_spanish_ci NOT NULL,
  `fechaini` date NOT NULL,
  `fechafin` date NOT NULL,
  PRIMARY KEY  (`cod_trimestre`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `trimestre`
--

INSERT INTO `trimestre` (`cod_trimestre`, `trimestre`, `fechaini`, `fechafin`) VALUES
(1, 'I', '2013-03-10', '2013-06-10'),
(2, 'II', '2013-06-11', '2013-09-10'),
(3, 'III', '2013-09-11', '2013-12-10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `cod_usuario` int(10) unsigned NOT NULL auto_increment,
  `usuario` varchar(20) collate utf8_spanish_ci NOT NULL,
  `clave` varchar(50) collate utf8_spanish_ci NOT NULL,
  `estado` tinyint(3) unsigned NOT NULL default '1',
  `fecha_registro` datetime NOT NULL,
  `conectado` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`cod_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`cod_usuario`, `usuario`, `clave`, `estado`, `fecha_registro`, `conectado`) VALUES
(1, 'luchop', '123456', 1, '2013-01-14 11:45:38', 0);

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `alternativa`
--
ALTER TABLE `alternativa`
  ADD CONSTRAINT `alternativa_ibfk_1` FOREIGN KEY (`cod_pregunta`) REFERENCES `pregunta` (`cod_pregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `capacidad`
--
ALTER TABLE `capacidad`
  ADD CONSTRAINT `capacidad_ibfk_1` FOREIGN KEY (`cod_area`) REFERENCES `areas` (`cod_area`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`cod_area`) REFERENCES `areas` (`cod_area`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cursogrado`
--
ALTER TABLE `cursogrado`
  ADD CONSTRAINT `cursogrado_ibfk_1` FOREIGN KEY (`cod_grado`) REFERENCES `grado` (`cod_grado`),
  ADD CONSTRAINT `cursogrado_ibfk_2` FOREIGN KEY (`cod_curso`) REFERENCES `curso` (`cod_curso`);

--
-- Filtros para la tabla `evaluacion`
--
ALTER TABLE `evaluacion`
  ADD CONSTRAINT `evaluacion_ibfk_2` FOREIGN KEY (`cod_tipoevaluacion`) REFERENCES `tipoevaluacion` (`cod_tipoevaluacion`),
  ADD CONSTRAINT `evaluacion_ibfk_3` FOREIGN KEY (`cod_curso`) REFERENCES `cursogrado` (`cod_curso`),
  ADD CONSTRAINT `evaluacion_ibfk_4` FOREIGN KEY (`cod_grado`) REFERENCES `cursogrado` (`cod_grado`);

--
-- Filtros para la tabla `evaluacion_pregunta`
--
ALTER TABLE `evaluacion_pregunta`
  ADD CONSTRAINT `evaluacion_pregunta_ibfk_1` FOREIGN KEY (`cod_evaluacion`) REFERENCES `evaluacion` (`cod_evaluacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `evaluacion_pregunta_ibfk_2` FOREIGN KEY (`cod_pregunta`) REFERENCES `pregunta` (`cod_pregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `grado`
--
ALTER TABLE `grado`
  ADD CONSTRAINT `grado_ibfk_1` FOREIGN KEY (`cod_nivel`) REFERENCES `nivel` (`cod_nivel`);

--
-- Filtros para la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD CONSTRAINT `pregunta_ibfk_5` FOREIGN KEY (`cod_grado`) REFERENCES `cursogrado` (`cod_grado`),
  ADD CONSTRAINT `pregunta_ibfk_1` FOREIGN KEY (`cod_niveldificultad`) REFERENCES `niveldificultad` (`cod_niveldificultad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pregunta_ibfk_4` FOREIGN KEY (`cod_curso`) REFERENCES `cursogrado` (`cod_curso`);

--
-- Filtros para la tabla `sesion`
--
ALTER TABLE `sesion`
  ADD CONSTRAINT `sesion_ibfk_1` FOREIGN KEY (`cod_usuario`) REFERENCES `usuario` (`cod_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `subtema`
--
ALTER TABLE `subtema`
  ADD CONSTRAINT `subtema_ibfk_1` FOREIGN KEY (`cod_tema`) REFERENCES `tema` (`cod_tema`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tema`
--
ALTER TABLE `tema`
  ADD CONSTRAINT `tema_ibfk_1` FOREIGN KEY (`cod_curso`) REFERENCES `cursogrado` (`cod_curso`),
  ADD CONSTRAINT `tema_ibfk_2` FOREIGN KEY (`cod_grado`) REFERENCES `cursogrado` (`cod_grado`);
