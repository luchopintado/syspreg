-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 21-02-2013 a las 03:26:06
-- Versión del servidor: 5.0.67
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sys_preg`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alternativa`
--

CREATE TABLE IF NOT EXISTS `alternativa` (
  `cod_alternativa` int(10) unsigned NOT NULL auto_increment,
  `cod_pregunta` int(10) unsigned NOT NULL,
  `valor` text NOT NULL,
  `correcta` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`cod_alternativa`),
  KEY `alternativa_FKIndex1` (`cod_pregunta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Volcar la base de datos para la tabla `alternativa`
--

INSERT INTO `alternativa` (`cod_alternativa`, `cod_pregunta`, `valor`, `correcta`) VALUES
(1, 1, '<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n  <mroot>\r\n    <mn>7</mn>\r\n    <mn>8</mn>\r\n  </mroot>\r\n</math>', 0),
(2, 1, '<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n  <mroot>\r\n    <mn>7</mn>\r\n    <mn>6</mn>\r\n  </mroot>\r\n</math>', 0),
(3, 1, '<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n  <mroot>\r\n    <mn>7</mn>\r\n    <mn>7</mn>\r\n  </mroot>\r\n</math>', 0),
(4, 1, '<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n  <mroot>\r\n    <mn>7</mn>\r\n    <mn>7</mn>\r\n  </mroot>\r\n</math>', 0),
(5, 1, '<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n  <mroot>\r\n    <mn>7</mn>\r\n    <mn>7</mn>\r\n  </mroot>\r\n</math>', 1),
(6, 2, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>7</mn>\n    <mn>7</mn>\n  </mroot>\n</math>', 0),
(7, 2, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>7</mn>\n    <mn>7</mn>\n  </mroot>\n</math>', 0),
(8, 2, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>7</mn>\n    <mn>7</mn>\n  </mroot>\n</math>', 0),
(9, 2, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>7</mn>\n    <mn>7</mn>\n  </mroot>\n</math>', 0),
(10, 2, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>7</mn>\n    <mn>7</mn>\n  </mroot>\n</math>', 1),
(11, 3, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(12, 3, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(13, 3, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(14, 3, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 1),
(15, 3, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(16, 4, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(17, 4, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(18, 4, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0),
(19, 4, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 1),
(20, 4, '<math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `areas`
--

CREATE TABLE IF NOT EXISTS `areas` (
  `cod_area` int(10) unsigned NOT NULL auto_increment,
  `areas` varchar(100) NOT NULL,
  PRIMARY KEY  (`cod_area`),
  UNIQUE KEY `idx_area_unique` (`areas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `areas`
--

INSERT INTO `areas` (`cod_area`, `areas`) VALUES
(3, 'Ciencia, Tecnología y Ambiente'),
(2, 'Comunicación'),
(1, 'Matemática');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `capacidad`
--

CREATE TABLE IF NOT EXISTS `capacidad` (
  `cod_capacidad` int(10) unsigned NOT NULL auto_increment,
  `cod_area` int(10) unsigned NOT NULL,
  `capacidad` varchar(100) NOT NULL,
  PRIMARY KEY  (`cod_capacidad`),
  KEY `capacidad_FKIndex1` (`cod_area`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `capacidad`
--

INSERT INTO `capacidad` (`cod_capacidad`, `cod_area`, `capacidad`) VALUES
(1, 1, 'Razonamiento y Demostración'),
(2, 1, 'Comunicación Matemática'),
(3, 1, 'Resolución de Problemas'),
(4, 1, 'Actitudes ante el área');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE IF NOT EXISTS `curso` (
  `cod_curso` int(10) unsigned NOT NULL auto_increment,
  `cod_area` int(10) unsigned NOT NULL,
  `curso` varchar(100) NOT NULL,
  PRIMARY KEY  (`cod_curso`),
  UNIQUE KEY `curso_FKIndex2` (`curso`),
  KEY `curso_FKIndex1` (`cod_area`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `curso`
--

INSERT INTO `curso` (`cod_curso`, `cod_area`, `curso`) VALUES
(1, 1, 'Algebra'),
(2, 1, 'Aritmética'),
(3, 1, 'Estadística'),
(4, 1, 'Geometría'),
(5, 1, 'Matemática'),
(6, 1, 'Razonamiento Lógico'),
(7, 1, 'Razonamiento Matemático'),
(8, 1, 'Trigonometría');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursogrado`
--

CREATE TABLE IF NOT EXISTS `cursogrado` (
  `cod_grado` int(10) unsigned NOT NULL,
  `cod_curso` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`cod_grado`,`cod_curso`),
  KEY `cursogrado_FKIndex1` (`cod_grado`),
  KEY `cursogrado_FKIndex2` (`cod_curso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `cursogrado`
--

INSERT INTO `cursogrado` (`cod_grado`, `cod_curso`) VALUES
(1, 5),
(1, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion`
--

CREATE TABLE IF NOT EXISTS `evaluacion` (
  `cod_evaluacion` int(10) unsigned NOT NULL auto_increment,
  `cod_curso` int(10) unsigned NOT NULL,
  `cod_grado` int(10) unsigned NOT NULL,
  `cod_tipoevaluacion` int(10) unsigned NOT NULL,
  `e_nombre` varchar(100) NOT NULL,
  `fecha_evaluacion` datetime NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `nro_preguntas` smallint(5) unsigned NOT NULL,
  `id_tema` int(10) unsigned default NULL,
  `id_subtema` int(10) unsigned default NULL,
  PRIMARY KEY  (`cod_evaluacion`),
  KEY `evaluacion_FKIndex1` (`cod_tipoevaluacion`),
  KEY `evaluacion_FKIndex2` (`cod_grado`,`cod_curso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `evaluacion`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion_pregunta`
--

CREATE TABLE IF NOT EXISTS `evaluacion_pregunta` (
  `cod_evaluacionpregunta` bigint(20) NOT NULL auto_increment,
  `cod_pregunta` int(10) unsigned NOT NULL,
  `cod_evaluacion` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`cod_evaluacionpregunta`),
  KEY `evaluacion_pregunta_FKIndex1` (`cod_evaluacion`),
  KEY `evaluacion_pregunta_FKIndex2` (`cod_pregunta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `evaluacion_pregunta`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grado`
--

CREATE TABLE IF NOT EXISTS `grado` (
  `cod_grado` int(10) unsigned NOT NULL auto_increment,
  `cod_nivel` int(10) unsigned NOT NULL,
  `grado` varchar(50) NOT NULL,
  PRIMARY KEY  (`cod_grado`),
  UNIQUE KEY `grado_FKIndex2` (`grado`,`cod_nivel`),
  KEY `grado_FKIndex1` (`cod_nivel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Volcar la base de datos para la tabla `grado`
--

INSERT INTO `grado` (`cod_grado`, `cod_nivel`, `grado`) VALUES
(4, 1, 'Cuarto'),
(10, 2, 'Cuarto'),
(1, 1, 'Primero'),
(7, 2, 'Primero'),
(5, 1, 'Quinto'),
(11, 2, 'Quinto'),
(2, 1, 'Segundo'),
(8, 2, 'Segundo'),
(6, 1, 'Sexto'),
(3, 1, 'Tercero'),
(9, 2, 'Tercero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel`
--

CREATE TABLE IF NOT EXISTS `nivel` (
  `cod_nivel` int(10) unsigned NOT NULL auto_increment,
  `nivel` varchar(20) NOT NULL,
  PRIMARY KEY  (`cod_nivel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `nivel`
--

INSERT INTO `nivel` (`cod_nivel`, `nivel`) VALUES
(1, 'Primaria'),
(2, 'Secundaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `niveldificultad`
--

CREATE TABLE IF NOT EXISTS `niveldificultad` (
  `cod_niveldificultad` tinyint(10) unsigned NOT NULL auto_increment,
  `niveldificultad` varchar(50) NOT NULL,
  PRIMARY KEY  (`cod_niveldificultad`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `niveldificultad`
--

INSERT INTO `niveldificultad` (`cod_niveldificultad`, `niveldificultad`) VALUES
(1, 'Básico'),
(2, 'Intermedio'),
(3, 'Avanzado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

CREATE TABLE IF NOT EXISTS `pregunta` (
  `cod_pregunta` int(10) unsigned NOT NULL auto_increment,
  `id_tipopregunta` int(10) unsigned NOT NULL,
  `cod_curso` int(10) unsigned NOT NULL,
  `cod_grado` int(10) unsigned NOT NULL,
  `cod_niveldificultad` tinyint(3) unsigned NOT NULL,
  `enunciado` text,
  `id_tema` int(10) unsigned default NULL,
  `id_subtema` int(10) unsigned default NULL,
  `fecha_registro` datetime NOT NULL,
  `id_capacidad` int(10) unsigned default NULL,
  `record` mediumint(8) unsigned NOT NULL default '1',
  PRIMARY KEY  (`cod_pregunta`),
  KEY `pregunta_FKIndex1` (`cod_niveldificultad`),
  KEY `pregunta_FKIndex2` (`cod_grado`,`cod_curso`),
  KEY `pregunta_FKIndex3` (`id_tipopregunta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `pregunta`
--

INSERT INTO `pregunta` (`cod_pregunta`, `id_tipopregunta`, `cod_curso`, `cod_grado`, `cod_niveldificultad`, `enunciado`, `id_tema`, `id_subtema`, `fecha_registro`, `id_capacidad`, `record`) VALUES
(1, 1, 5, 1, 1, 'Encuentra x en la ecuacion:\r\n<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n<mroot>\r\n<mn>5</mn>\r\n<mn>3</mn>\r\n</mroot>\r\n</math>', 1, 0, '2013-02-18 12:44:25', 1, 1),
(2, 1, 5, 1, 2, 'Demuestra la siguiente ecuacion:\r\n<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n<mroot>\r\n<mn>5</mn>\r\n<mn>3</mn>\r\n</mroot>\r\n</math>', 1, 0, '2013-02-18 12:46:38', 1, 1),
(3, 2, 5, 1, 3, 'Resolver la siguiente ecuacion:\r\n<math xmlns="http://www.w3.org/1998/Math/MathML">\r\n<mroot>\r\n<mn>5</mn>\r\n<mn>3</mn>\r\n</mroot>\r\n</math>', 2, 0, '2013-02-18 12:58:17', 2, 1),
(4, 2, 5, 1, 2, 'Resolver: <math xmlns="http://www.w3.org/1998/Math/MathML">\n  <mroot>\n    <mn>5</mn>\n    <mn>3</mn>\n  </mroot>\n</math>', 2, 0, '2013-02-18 13:05:29', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesion`
--

CREATE TABLE IF NOT EXISTS `sesion` (
  `cod_sesion` int(10) unsigned NOT NULL auto_increment,
  `cod_usuario` int(10) unsigned NOT NULL,
  `fecha_login` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  `fecha_logout` datetime NOT NULL,
  PRIMARY KEY  (`cod_sesion`),
  KEY `sesion_FKIndex1` (`cod_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `sesion`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subtema`
--

CREATE TABLE IF NOT EXISTS `subtema` (
  `cod_subtema` int(10) unsigned NOT NULL auto_increment,
  `cod_tema` int(10) unsigned NOT NULL,
  `st_nombre` varchar(100) default NULL,
  PRIMARY KEY  (`cod_subtema`),
  KEY `subtema_FKIndex1` (`cod_tema`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `subtema`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tema`
--

CREATE TABLE IF NOT EXISTS `tema` (
  `cod_tema` int(10) unsigned NOT NULL auto_increment,
  `cod_trimestre` int(10) unsigned NOT NULL,
  `cod_curso` int(10) unsigned NOT NULL,
  `cod_grado` int(10) unsigned NOT NULL,
  `tema` varchar(100) NOT NULL,
  `id_capacidad` int(10) unsigned default NULL,
  PRIMARY KEY  (`cod_tema`),
  KEY `tema_FKIndex1` (`cod_grado`,`cod_curso`),
  KEY `tema_FKIndex2` (`cod_trimestre`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `tema`
--

INSERT INTO `tema` (`cod_tema`, `cod_trimestre`, `cod_curso`, `cod_grado`, `tema`, `id_capacidad`) VALUES
(1, 1, 5, 1, 'Conteo de figuras', 1),
(2, 1, 5, 1, 'Demostración de teoremas', 2),
(3, 1, 5, 1, 'Ecuaciones de primer grado (Problemas)', 3),
(4, 1, 5, 1, 'Ecuaciones de primer grado', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoevaluacion`
--

CREATE TABLE IF NOT EXISTS `tipoevaluacion` (
  `cod_tipoevaluacion` int(10) unsigned NOT NULL auto_increment,
  `tipoevaluacion` varchar(50) NOT NULL,
  PRIMARY KEY  (`cod_tipoevaluacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `tipoevaluacion`
--

INSERT INTO `tipoevaluacion` (`cod_tipoevaluacion`, `tipoevaluacion`) VALUES
(1, 'Actividad en clase'),
(2, 'Evaluación');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trimestre`
--

CREATE TABLE IF NOT EXISTS `trimestre` (
  `cod_trimestre` int(10) unsigned NOT NULL auto_increment,
  `trimestre` char(4) NOT NULL,
  `fechaini` date NOT NULL,
  `fechafin` date NOT NULL,
  PRIMARY KEY  (`cod_trimestre`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `trimestre`
--

INSERT INTO `trimestre` (`cod_trimestre`, `trimestre`, `fechaini`, `fechafin`) VALUES
(1, 'I', '2013-03-16', '2013-06-15'),
(2, 'II', '2013-06-16', '2013-09-15'),
(3, 'III', '2013-09-16', '2013-12-15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `cod_usuario` int(10) unsigned NOT NULL auto_increment,
  `usuario` varchar(20) default NULL,
  `clave` varchar(50) default NULL,
  `estado` tinyint(3) unsigned default '1',
  `fecha_registro` datetime default NULL,
  `conectado` tinyint(3) unsigned default '0',
  PRIMARY KEY  (`cod_usuario`),
  UNIQUE KEY `usuario_FKIndex1` (`usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`cod_usuario`, `usuario`, `clave`, `estado`, `fecha_registro`, `conectado`) VALUES
(1, 'admin', '123456', 1, '2013-02-14 11:37:00', 0);

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `alternativa`
--
ALTER TABLE `alternativa`
  ADD CONSTRAINT `alternativa_ibfk_1` FOREIGN KEY (`cod_pregunta`) REFERENCES `pregunta` (`cod_pregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `capacidad`
--
ALTER TABLE `capacidad`
  ADD CONSTRAINT `capacidad_ibfk_1` FOREIGN KEY (`cod_area`) REFERENCES `areas` (`cod_area`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`cod_area`) REFERENCES `areas` (`cod_area`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cursogrado`
--
ALTER TABLE `cursogrado`
  ADD CONSTRAINT `cursogrado_ibfk_1` FOREIGN KEY (`cod_grado`) REFERENCES `grado` (`cod_grado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `cursogrado_ibfk_2` FOREIGN KEY (`cod_curso`) REFERENCES `curso` (`cod_curso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `evaluacion`
--
ALTER TABLE `evaluacion`
  ADD CONSTRAINT `evaluacion_ibfk_1` FOREIGN KEY (`cod_tipoevaluacion`) REFERENCES `tipoevaluacion` (`cod_tipoevaluacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `evaluacion_ibfk_2` FOREIGN KEY (`cod_grado`, `cod_curso`) REFERENCES `cursogrado` (`cod_grado`, `cod_curso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `evaluacion_pregunta`
--
ALTER TABLE `evaluacion_pregunta`
  ADD CONSTRAINT `evaluacion_pregunta_ibfk_1` FOREIGN KEY (`cod_evaluacion`) REFERENCES `evaluacion` (`cod_evaluacion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `evaluacion_pregunta_ibfk_2` FOREIGN KEY (`cod_pregunta`) REFERENCES `pregunta` (`cod_pregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `grado`
--
ALTER TABLE `grado`
  ADD CONSTRAINT `grado_ibfk_1` FOREIGN KEY (`cod_nivel`) REFERENCES `nivel` (`cod_nivel`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD CONSTRAINT `pregunta_ibfk_2` FOREIGN KEY (`cod_grado`, `cod_curso`) REFERENCES `cursogrado` (`cod_grado`, `cod_curso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pregunta_ibfk_3` FOREIGN KEY (`cod_niveldificultad`) REFERENCES `niveldificultad` (`cod_niveldificultad`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `sesion`
--
ALTER TABLE `sesion`
  ADD CONSTRAINT `sesion_ibfk_1` FOREIGN KEY (`cod_usuario`) REFERENCES `usuario` (`cod_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `subtema`
--
ALTER TABLE `subtema`
  ADD CONSTRAINT `subtema_ibfk_1` FOREIGN KEY (`cod_tema`) REFERENCES `tema` (`cod_tema`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tema`
--
ALTER TABLE `tema`
  ADD CONSTRAINT `tema_ibfk_1` FOREIGN KEY (`cod_grado`, `cod_curso`) REFERENCES `cursogrado` (`cod_grado`, `cod_curso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tema_ibfk_2` FOREIGN KEY (`cod_trimestre`) REFERENCES `trimestre` (`cod_trimestre`) ON DELETE NO ACTION ON UPDATE NO ACTION;
